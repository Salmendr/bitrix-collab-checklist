import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent

# Runtime-╤Е╤А╨░╨╜╨╕╨╗╨╕╤Й╨╡ ╨┐╤А╨╛╨╡╨║╤В╨░.
# ╨Э╨╡ ╨┐╨╡╤А╨╡╨╜╨╛╤Б╨╕╨╝, ╨╜╨╡ ╨┐╨╡╤А╨╡╨╕╨╝╨╡╨╜╨╛╨▓╤Л╨▓╨░╨╡╨╝, ╨╜╨╡ ╤Б╨╛╨╖╨┤╨░╤С╨╝ ╨▓╤А╤Г╤З╨╜╤Г╤О ╨▓ ╤А╨░╨╝╨║╨░╤Е ╤А╨╡╤Д╨░╨║╤В╨╛╤А╨╕╨╜╨│╨░.
VOLUME_DIR = BASE_DIR / "Volume"

DB_DIR = VOLUME_DIR / "db"
DB_PATH = str(DB_DIR / "app.db")

APP_PORTAL_PATH = (os.getenv("APP_PORTAL_PATH", "/marketplace/app/80/") or "/marketplace/app/80/").strip()
APP_BASE_PATH = (os.getenv("APP_BASE_PATH", "") or "").strip()
PUBLIC_APP_BASE_URL = (os.getenv("PUBLIC_APP_BASE_URL", "") or "").strip()

TECH_USER_ID = int(os.getenv("TECH_USER_ID", "138"))
BITRIX_TECH_WEBHOOK_URL = os.getenv("BITRIX_TECH_WEBHOOK_URL", "").strip()
N8N_SHARED_TOKEN = os.getenv("N8N_SHARED_TOKEN", "").strip()

YANDEX_DISK_OAUTH_TOKEN = os.getenv("YANDEX_DISK_OAUTH_TOKEN", "").strip()
YANDEX_DISK_API_BASE = "https://cloud-api.yandex.net/v1/disk"

UPLOAD_ROOT = VOLUME_DIR / "uploads"
CHECKLIST_UPLOAD_ROOT = UPLOAD_ROOT / "checklists"
EDIT_SESSION_FILE_ROOT = VOLUME_DIR / "edit_sessions"

DEBUG_DIR = BASE_DIR / "debug"
DEBUG_LOG_PATH = DEBUG_DIR / "close_popup.log"

EDIT_LOCK_TTL_SECONDS = 45
EDIT_LOCK_HEARTBEAT_SECONDS = 15

# ╨У╨╗╨╛╨▒╨░╨╗╤М╨╜╨░╤П ╤В╤А╨░╨╜╨╖╨░╨║╤Ж╨╕╨╛╨╜╨╜╨░╤П ╤Б╨╡╤Б╤Б╨╕╤П popup.
# ╨Я╤П╤В╤М ╨╝╨╕╨╜╤Г╤В ╨▒╨╡╨╖ heartbeat ╨╛╨╖╨╜╨░╤З╨░╤О╤В abandoned-╤Б╨╡╤Б╤Б╨╕╤О.
# ╨в╨░╨║╨░╤П ╤Б╨╡╤Б╤Б╨╕╤П ╨░╨▓╤В╨╛╨╝╨░╤В╨╕╤З╨╡╤Б╨║╨╕ ╤Б╨╛╤Е╤А╨░╨╜╤П╨╡╤В╤Б╤П ╤З╨╡╤А╨╡╨╖ commit; rollback ╤А╨░╨╖╤А╨╡╤И╤С╨╜
# ╤В╨╛╨╗╤М╨║╨╛ ╨┐╨╛╤Б╨╗╨╡ ╤П╨▓╨╜╨╛╨│╨╛ ╨┐╨╛╨┤╤В╨▓╨╡╤А╨╢╨┤╤С╨╜╨╜╨╛╨│╨╛ ╨╜╨░╨╢╨░╤В╨╕╤П ╨║╨╜╨╛╨┐╨║╨╕ ┬л╨Ю╤В╨╝╨╡╨╜╨╕╤В╤М┬╗.
EDIT_SESSION_TTL_SECONDS = 300
EDIT_SESSION_HEARTBEAT_SECONDS = 20
EDIT_SESSION_SWEEP_SECONDS = 15

def ensure_runtime_directories():
    """
    ╨б╨╛╨╖╨┤╨░╤С╤В ╤В╨╛╨╗╤М╨║╨╛ ╤И╤В╨░╤В╨╜╤Л╨╡ runtime-╨┤╨╕╤А╨╡╨║╤В╨╛╤А╨╕╨╕ ╨┐╤А╨╕╨╗╨╛╨╢╨╡╨╜╨╕╤П.

    ╨н╤В╨╛ ╨╜╨╡ ╨╝╨╡╨╜╤П╨╡╤В ╨░╤А╤Е╨╕╤В╨╡╨║╤В╤Г╤А╤Г Volume:
    - ╨▒╨░╨╖╨░ ╨╛╤Б╤В╨░╤С╤В╤Б╤П ╨▓ Volume/db/app.db;
    - ╨╖╨░╨│╤А╤Г╨╖╨║╨╕ ╨╛╤Б╤В╨░╤О╤В╤Б╤П ╨▓ Volume/uploads;
    - app/ ╨╛╤Б╤В╨░╤С╤В╤Б╤П ╤В╨╛╨╗╤М╨║╨╛ ╨║╨╛╨┤╨╛╨╝.
    """
    VOLUME_DIR.mkdir(parents=True, exist_ok=True)
    DB_DIR.mkdir(parents=True, exist_ok=True)
    UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
    CHECKLIST_UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
    EDIT_SESSION_FILE_ROOT.mkdir(parents=True, exist_ok=True)
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
