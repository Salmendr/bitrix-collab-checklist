﻿from __future__ import annotations

import ast
import sys
import traceback
from pathlib import Path

root = Path.cwd().resolve()
errors: list[str] = []

files = sorted((root / "app").rglob("*.py"))
files.append(root / "main.py")

for path in files:
    try:
        source = path.read_text(encoding="utf-8-sig")
        ast.parse(source, filename=str(path))
    except Exception:
        errors.append(
            f"{path.relative_to(root)}\n{traceback.format_exc()}"
        )

print(f"python_files={len(files)}")
print(f"syntax_errors={len(errors)}")

for error in errors:
    print(error)

try:
    from main import app

    print("main_import_ok=true")
    print(f"route_count={len(app.routes)}")
except Exception:
    print("main_import_ok=false")
    print(traceback.format_exc())
    raise

if errors:
    raise SystemExit(1)